<?php
$con = mysqli_connect ("localhost","id13252661_root","karanYADAV22!","id13252661_job");

?>
